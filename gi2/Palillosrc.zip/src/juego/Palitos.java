package juego;

import java.util.Scanner;

public class Palitos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int palitos = 21;
		
		
       
       
   
       
       do {
    	   System.out.println("Hay "+ palitos );
           System.out.println("Cuantos palitos quitas?");
           Scanner reader = new Scanner(System.in);
           int numero = reader.nextInt();
           palitos=palitos-numero;
           System.out.println("Quedan "+ palitos);
    	   
           int ia;
           
           ia = numero -5;
           ia= ia*-1;
           if(ia==0) {
        	   
        	  ia= ia+5;
        	   
           }
        
           if(palitos>0) {
           System.out.println("la ia a quitado " +ia);
           palitos = palitos-ia;
        
           }
    	   
    	   
       } while(palitos>0);
       
        
       
	}

}
